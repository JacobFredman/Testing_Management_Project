﻿using System.Collections.Generic;
using BE;

namespace DS
{
    public static class DataSource
    {
        public static  List<Trainee> Trainees = new List<Trainee>();
        public static  List<Tester> Testers = new List<Tester>();
        public static  List<Test> Tests = new List<Test>();
    }


}
