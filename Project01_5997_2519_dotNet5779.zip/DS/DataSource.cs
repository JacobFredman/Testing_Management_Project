﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace DS
{
    public class DataSource
    {
        public List<Trainee> Trainees = new List<Trainee>();
        public List<Tester> Testers = new List<Tester>();
        public List<Test> Tests = new List<Test>();
        public DataSource()
        {

        }
    }
}
