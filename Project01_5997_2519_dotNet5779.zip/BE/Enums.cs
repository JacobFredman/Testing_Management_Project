﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public enum Gender { Male, Female }
    public enum LicenceType { B, A2, A1, A, C1, C, D, D1, D2, D3, E, _1 }
    public enum GearType { Automat, Manual }
    public enum Days { Sunday, Monday, Tuersday, Wednesday, Thursday, Friday, Saturday }
}
