﻿namespace BE
{
   public  enum Gender { Male, Female }
   public enum LicenceType {B, A2,A1,A,C1,C,D,D1,D2,D3,E,_1}
   public  enum GearType { Automatic,Manual}
   public  enum Days { Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday}
}
